//
//  pritam_ViewController.h
//  testStatusBar
//
//  Created by elie maalouly on 10/31/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MTStatusBarOverlay.h"

@interface pritam_ViewController : UIViewController<MTStatusBarOverlayDelegate>

@end
